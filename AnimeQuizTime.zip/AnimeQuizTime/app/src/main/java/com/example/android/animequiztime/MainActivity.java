package com.example.android.animequiztime;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String rank[] = {"Genin Anime Watcher", " Chunin Anime Watcher", "Espada Anime Watcher", "Legendary Super Sayian Anime Watcher",
            "Hokage Anime Watcher", "Dragon Force Ultimate Anime Watcher", "One Punch Man!", "Super Sayian God Mastered Ultra instinct!"};
    private int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Method for user to send results to their Own Mail.
     */
    public void sendMail(View view) {
        String addresses[] = {getUserEmail()};
        composeEmail(addresses, getMailSubject(), getScoreResultsMessage());
    }

    /**
     * Submit Method executed upon clicking the Submit Button to generate the result
     */
    public void submit(View view) {

        int questionOneScore = 0;
        int questionThreeScore = 0;
        int questionFourScore = 0;
        int questionFiveScore = 0;
        int questionSixScore = 0;

        RadioGroup answer = findViewById(R.id.answers_1);
        int selectedAnswer = answer.getCheckedRadioButtonId();
        RadioButton selectedUserAnswer = findViewById(selectedAnswer);
        RadioButton correctAnswer = findViewById(R.id.osamu_radio_button);

        if (selectedUserAnswer == correctAnswer) {
            questionOneScore = 10;
        }
/**
 * Question#2 get the inputs for the Checkboxes
 */
        CheckBox answerSpirited = findViewById(R.id.spirited_checkbox);
        boolean spiritedCheck = answerSpirited.isChecked();

        CheckBox answerDragonball = findViewById(R.id.dragonball_checkbox);
        boolean dragonballCheck = answerDragonball.isChecked();

        CheckBox answerShield = findViewById(R.id.shieldhero_checkbox);
        boolean shieldCheck = answerShield.isChecked();

        CheckBox answerFullmetal = findViewById(R.id.fullmetal_checkbox);
        boolean fullmetalCheck = answerFullmetal.isChecked();

        CheckBox answerSamurai = findViewById(R.id.samuraijack_checkbox);
        boolean samuraiCheck = answerSamurai.isChecked();

        CheckBox answerlooney = findViewById(R.id.looney_checkbox);
        boolean looneyCheck = answerlooney.isChecked();

/**
 * Question#3 get user input on the radio button and compare if answer is correct
 */
        RadioGroup answerThree = findViewById(R.id.answers_3);
        int selectedAnswerThree = answerThree.getCheckedRadioButtonId();
        RadioButton selectedUserAnswerThree = findViewById(selectedAnswerThree);
        RadioButton correctAnswerThree = findViewById(R.id.sexy_radio_button);


        if (selectedUserAnswerThree == correctAnswerThree) {
            questionThreeScore = 10;
        }
/**
 * Question#4 get user input and compare if input is correct
 */
        EditText answerGoku = findViewById(R.id.answer_4);
        Editable answerEnteredfour = answerGoku.getText();
        String ansUserEntered = answerEnteredfour.toString();
        if (ansUserEntered.equalsIgnoreCase("kamehameha")) {
            questionFourScore = 10;
        }
/**
 * Question#5 get user input and compare if the answer is correct
 */
        RadioGroup answerFive = findViewById(R.id.answers_5);
        int selectedAnswerFive = answerFive.getCheckedRadioButtonId();
        RadioButton selectedUserAnswerFive = findViewById(selectedAnswerFive);
        RadioButton correctAnswerFive = findViewById(R.id.masashi_radio_button);

        if (selectedUserAnswerFive == correctAnswerFive) {
            questionFiveScore = 10;
        }

/**
 * Question#6 get user input and compare the String data to see if it is a correct answer
 */
        EditText answerTitan = findViewById(R.id.answers_6);
        Editable answerEnteredSix = answerTitan.getText();
        String ansUserEnteredSix = answerEnteredSix.toString();
        if (ansUserEnteredSix.equalsIgnoreCase("attack on titan")) {
            questionSixScore = 10;
        }

        CheckBox answerBonusSevenxxxx = findViewById(R.id.awesomex5_checkbox);
        boolean awesomecheckSevenxxxx = answerBonusSevenxxxx.isChecked();

/**
 * @Param score the final score of the user
 * a Toast message is given with the final score
 */
        score = questionOneScore + calculateScore(spiritedCheck, dragonballCheck, shieldCheck, fullmetalCheck, samuraiCheck, looneyCheck) +
                questionThreeScore + questionFourScore + questionFiveScore + questionSixScore + calculateBonusScore(awesomecheckSevenxxxx);
        Toast.makeText(this, getScoreResultsMessage(), Toast.LENGTH_SHORT).show();
    }

    /**
     * Bonus Question turn the other Checkboxes true when "OK all of the Above" Checkbox is clicked
     */
    public void bonusPoint(View view) {

        CheckBox answerBonusSeven = findViewById(R.id.awesome_checkbox);
        answerBonusSeven.setChecked(true);


        CheckBox answerBonusSevenx = findViewById(R.id.awesomex2_checkbox);
        answerBonusSevenx.setChecked(true);

        CheckBox answerBonusSevenxx = findViewById(R.id.awesomex3_checkbox);
        answerBonusSevenxx.setChecked(true);

        CheckBox answerBonusSevenxxx = findViewById(R.id.awesomex4_checkbox);
        answerBonusSevenxxx.setChecked(true);
    }

    /**
     * Method to get user name and email
     */
    private String getUserName() {
        EditText userName = findViewById(R.id.your_name);
        String name = userName.getText().toString();
        return name;
    }

    private String getUserEmail() {
        EditText userEmail = findViewById(R.id.your_email);
        String email = userEmail.getText().toString();
        return email;
    }


    /**
     * Method to calculate the points gained from Question#2
     *
     * @param choiceSpirited   the boolean value of Question2
     * @param choiceDragonball the boolean value of Question2
     * @param choiceShield     the boolean value of Question2
     * @param choiceFullmetal  the boolean value of Question2
     * @return returns the score according to the user's selection
     */
    private int calculateScore(boolean choiceSpirited, boolean choiceDragonball, boolean choiceShield, boolean choiceFullmetal, boolean choicesamurai, boolean choicelooney) {
        int questionTwoScore = 0;
        if (choiceSpirited && choiceDragonball && choiceShield && choiceFullmetal && !choicesamurai && !choicelooney) {
            questionTwoScore = 10;
        }
        return questionTwoScore;
    }

    /**
     * Method to calculate the Bonus Question points
     *
     * @param awesome Boolean to check if the correct answer was selected
     * @return questionSevenScore is the points for the user's answer to the bonus question
     */
    private int calculateBonusScore(boolean awesome) {
        int questionSevenScore = 0;
        if (awesome) {
            questionSevenScore = 10;
        }
        return questionSevenScore;

    }

    /**
     * Gives the User his rank according to his final score
     *
     * @return yourRank a String value containing the User's Rank
     */
    private String challengerRank() {
        String yourRank = "";
        int currentScore = score / 10;
        for (int x = 0; x <= 7; x++) {
            if (x == currentScore) {
                yourRank = rank[x];
            }
        }
        return yourRank;
    }

    /**
     * Displays the Results of the user in a Text form
     *
     * @Param scoreResults is the String that holds the user's details and score.
     */
    private String getScoreResultsMessage() {
        String scoreResults = "Challenger : " + getUserName();
        scoreResults += "\nscore: " + score;
        scoreResults += "\nRank: " + challengerRank();
        return scoreResults;
    }

    /**
     * Method to get the mail Subject to display in the mail to send to user
     *
     * @return mailSubject is the Email Subject when sending the email
     */
    private String getMailSubject() {
        String mailSubject = getUserName() + " Anime Quiz Results";
        return mailSubject;
    }

    /**
     * Mehtod to send a mail to user
     */
    public void composeEmail(String[] addresses, String subject, String msg) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, msg);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}